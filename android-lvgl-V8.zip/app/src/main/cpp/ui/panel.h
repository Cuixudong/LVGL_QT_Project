﻿#ifndef H_PANEL
#define H_PANEL

#include "../lvgl/lvgl.h"

void panel_main(int width, int height);

#endif