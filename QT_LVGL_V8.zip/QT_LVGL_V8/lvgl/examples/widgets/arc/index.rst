C
^

Simple Arc 
""""""""""""""""

.. lv_example:: widgets/arc/lv_arc_example_1
  :language: c

Loader with Arc 
""""""""""""""""

.. lv_example:: widgets/arc/lv_arc_example_2
  :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
