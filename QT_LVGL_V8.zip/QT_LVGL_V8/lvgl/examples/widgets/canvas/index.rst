C
^

Drawing on the Canvas and rotate 
""""""""""""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_canvas/lv_ex_canvas_1
  :language: c

Transparent Canvas with chroma keying
""""""""""""""""""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_canvas/lv_ex_canvas_2
  :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
