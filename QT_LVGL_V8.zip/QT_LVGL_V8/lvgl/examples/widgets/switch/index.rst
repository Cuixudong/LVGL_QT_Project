C
^

Simple Switch 
"""""""""""""""""""""""

.. lv_example:: lv_ex_widgets/lv_ex_switch/lv_ex_switch_1
  :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
