
Simple spinner 
""""""""""""""""""""""""""""

.. lv_example:: widgets/spinner/lv_example_spinner_1
  :language: c

